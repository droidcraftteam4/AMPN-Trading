<?php

    $product_code=$_POST['product_code'];

  
	
    if ($product_code == "")
    {
    echo"<p>Required Field(s) missing! Go back and Try again.</p>";
    }
   
    else
    {
    //Connect to the server and add a new record 

	$hostname= "sql310.byethost7.com";
	$database = "b7_18180348_website";
	$user = "b7_18180348";
	$pass = "xfn61kmt";
	$mysql_link=mysql_connect($hostname,$user,$pass) or die( "Unable to connect to the server");
	mysql_select_db($database) or die( "Unable to select the database");

    $query = "Delete from products where (product_code = '$product_code')";
    mysql_query($query) or die( "Unable to delete the record");
    mysql_close();
    echo "<p> <b>Product Deleted Successfully. </p>";



    }
?>
