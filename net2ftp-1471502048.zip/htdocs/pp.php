<?php
include('header.html');
?>



<?php
$conn = mysql_connect("sql310.byethost7.com","b7_18180348","xfn61kmt");
mysql_select_db("b7_18180348_website", $conn);
$seetable = "Select product_code, name,description,image from products";

$result1 = mysql_query($seetable, $conn);
$url = 'http://ampntrading.byethost7.com/products.php';
$final = $url . "?" . http_build_query($rows[0]);
define('COLS', 3); // number of columns
$col = 0; // number of the last column filled

echo '<form method="get" action="products.php"><table class="inner_table" align="center">';
echo '<tr>'; // start first row

while ($rows = mysql_fetch_array($result1))
{
  if ($col == COLS) // last time filled the last column
  { echo '</tr><tr>'; // start new row -- "linebreak" sequence
    $col = 1; // so now we're filling first column
  } else  $col++;  // increment otherwise

  echo '<td class="sub_table"><center>';
  echo '<a href="http://ampntrading.byethost7.com/products.php?"'.$rows[0].'><img src="'.$rows[3].'" class="img-thumbnail" height=300 width=300/></a><br><span class="index_list_bold">', $rows[1], '<span><br><span class="index_list"><br>', $rows[0],'<br>','<br></span>', '</center></td>';

}

session_start();
$_SESSION["pcode"] = $rows[0];
echo $_SESSION["pcode"];

echo '</tr>'; // end last row
echo "</table></form>";



// free result set memory 
mysql_free_result($result); 

// close connection 
mysql_close($connection); 

?>
<?php
include('footer.html');
?>