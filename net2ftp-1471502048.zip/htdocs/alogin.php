<?php

$email = $_POST['email'];
$password=$_POST['password'];
if (($email=="") || ($password=="")) {
    echo "Error, Please go back and fill the form";
}
else
	{   

	//connect to server and select database
	$hostname= "sql310.byethost7.com";
	$database = "b7_18180348_website";
	$user = "b7_18180348";
	$pass = "xfn61kmt";
	$mysql_link=mysql_connect($hostname,$user,$pass) or die( "Unable to connect to the server");
	mysql_select_db($database) or die( "Unable to select the database");
   //	$password = md5($password);
	//create and issue the query
	$query = "SELECT email, password from admin WHERE (email = '$email') AND (password = '$password')";
	$result2 = mysql_query($query) or die( "Invalid email or password");

	
	if (mysql_num_rows($result2) == 1) {
   	
    	session_start();
	$_SESSION['admin'] = $email;
   
header ("Location: adminarea.php");
		mysql_close();
		}
		else
		{
			 echo "<h2>Error, Please go back and fill the form</h2>";
session_start();
$_SESSION['admin'] = '';
		}
}
