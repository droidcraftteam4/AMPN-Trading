<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,  color: #3e94ec; initial-scale=1">
<title>Contact us</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="New folder/css/bootstrap.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<?php
include('header.html');
?>

<hr>
<h2 class="text-center">Contact us</h2>
<hr>
<div class="container">
<div class="row">

  <div class="col-md-6">
<div style="text-decoration:none; overflow:hidden; height:500px; width:500px; max-width:100%;">
<div id="my-map-canvas" style="height:100%; width:100%;max-width:100%;">
<iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=63+South+Rd,+Hindmarsh,+South+Australia,+5007,+Australia&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU">
</iframe></div><a class="google-map-enabler" rel="nofollow" href="https://www.hostingreviews.website/compare/hostgator-vs-godaddy" id="enable-map-data">godaddy vs hostgator</a><style>
#my-map-canvas .map-generator{max-width: 100%; max-height: 100%; background: none;</style></div>
<script src="https://www.hostingreviews.website/google-maps-authorization.js?id=71e09c8b-cb3d-5aff-e9e7-7318ce717491&c=google-map-enabler&u=1470307068" defer="defer" async="async"></script></div>
<div class="col-md-6">


<div id="info">
    <p>AMPN Trading Pty Ltd</p>
    <p>63 South Rd, Hindmarsh 5007 </p>
    <p>P: 0418 829 180</p>
    <p>admin@ampntrading.com.au</p>
</div>
<nav class="text-left">

  </nav>
</div>
</div>
</div>
<?php
include('footer.html');
?>
<script src="New folder/js/jquery-1.11.2.min.js"></script> 
<script src="New folder/js/bootstrap.min.js"></script>
</body>
</html>
		