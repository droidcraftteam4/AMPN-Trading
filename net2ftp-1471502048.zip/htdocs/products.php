<?php
$pcode = intval($_GET['pcode']); 
$sql = mysqli_query($conn,"SELECT * FROM products WHERE product_id = ".$id);
if(mysqli_num_rows($sql)){
    $product_data = mysqli_fetch_array($sql);
    echo "<h2><center>".$product_data['title']."</h2></center>";
}
?>