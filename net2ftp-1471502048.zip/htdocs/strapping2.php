﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Strapping & Tying Products</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="New folder/css/bootstrap.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<?php
include('header.html');
?>
<div class="container">
<?php


$conn = mysql_connect("sql310.byethost7.com","b7_18180348","xfn61kmt");
mysql_select_db("b7_18180348_website", $conn);
$seetable = "Select * from products where catagory like 'Protective%'";

print "<table class='table-fill' align='center' cellpadding=5 cellspacing=5 border=0 height=90%  sortable>
       <thead><th>Product Name</th><th>Name</th><th>Image</th>
     </thead>\n";

$result1 = mysql_query($seetable, $conn);
while ($row = mysql_fetch_assoc($result1))   {
   print "<tbody class='table-hover'><tr><td>$row[name]</td> </tr>
             <tr> <td>$row[description]</td> </tr>
             <tr> <td height=350 width=350> <img src=$row[image] ></td> </tr>
             
           </tbody>\n";            
                 }
print "</table><br>";
mysql_close();
?>

 </div>
  <nav class="text-center"  hidden>
    <!-- Add class .pagination-lg for larger blocks or .pagination-sm for smaller blocks-->
    <ul class="pagination">
      <li> <a href="#" aria-label="Previous"> <span aria-hidden="true">&laquo;</span> </a> </li>
      <li class="active"><a href="#">1</a></li>
      <li><a href="#">2</a></li>
      <li><a href="#">3</a></li>
      <li><a href="#">4</a></li>
      <li class="disabled"><a href="#">5</a></li>
      <li> <a href="#" aria-label="Next"> <span aria-hidden="true">&raquo;</span> </a> </li>
    </ul>
  </nav>
</div>
<hr>
<?php
include('footer.html');
?>
<script src="New folder/js/jquery-1.11.2.min.js"></script> 
<script src="New folder/js/bootstrap.min.js"></script>
</body>
</html>		