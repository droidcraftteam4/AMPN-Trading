<?php
    $product_code=$_POST['product_code'];
    $name=$_POST['name'];
    $description=$_POST['description'];
    $image=$_POST['image'];
  
	
    if (($product_code == "") or ($name == "") or ($description == "")or ($image == ""))
    {
    echo"<p>Required Field(s) missing! Go back and Try again.</p>";
    }
   
    else
    {
    //Connect to the server and add a new record 

	$hostname= "sql310.byethost7.com";
	$database = "b7_18180348_website";
	$user = "b7_18180348";
	$pass = "xfn61kmt";
	$mysql_link=mysql_connect($hostname,$user,$pass) or die( "Unable to connect to the server");
	mysql_select_db($database) or die( "Unable to select the database");

    $query = "INSERT INTO products VALUES ('$product_code','$name','$description','$image')";
    mysql_query($query) or die( "Unable to insert the record");
    mysql_close();
    echo "<p> <b>Product Added Successfully. </p>";
    echo"<p> <a href=adminarea.php>Click Here to go back </a> </b></p>";


    }
?>
